<?php
    $num = 23.8;
    if(is_array($num)) {
        echo "Numero inteiro";
    }
    else {
        echo "O valor da variavel não é um numero inteiro!";
    }

?>