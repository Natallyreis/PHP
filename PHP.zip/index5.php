<?php
    $num = 23.8;
    if(is_long($num)) {
        echo "Numero inteiro";
    }
    else {
        echo "O valor da variavel não é um numero inteiro!";
    }

?>