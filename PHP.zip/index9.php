<?php
    $num = 23.8;
    if(is_object($num)) {
        echo "Numero inteiro";
    }
    else {
        echo "O valor da variavel não é um numero inteiro!";
    }

?>